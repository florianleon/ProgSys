#include <stdio.h>
#include <unistd.h> 
#include <stdlib.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <math.h>

//j'utilise ce fichier pour creer les deux tubes

int main() {

    struct timeval td, tf;

    //creation des 2 tubes 
    int fd1, fd2;
    //tube pour ecrire 
    mkfifo("tube1", S_IRUSR | S_IWUSR | S_IRGRP); 
    //tube pour lire
    mkfifo("tube2", S_IRUSR | S_IWUSR | S_IRGRP); 
    
    int taille_buf = 1000; //remplace le PIPE_BUF;
    //on ouvre le premier tube dans le sens ecriture 
    //la synchro est faite avec le open
    printf("attente open\n");
    if ((fd1 = open("tube1", O_WRONLY)) == -1) {
        printf("echec du open 1 : Sortie du programme !\n");
        exit(0);
    }
    // fd1 = open("tube1", O_WRONLY);
    //on ouvre le deuxieme tube dans le sens lecture
    if ((fd2 = open("tube2", O_RDONLY)) == -1) {
        printf("echec du open 2 : Sortie du programme !\n");
        exit(0);
    }
    printf("Fin open\n");
    char * buf; //sert a ecrire dans le fichier 
    buf = malloc(sizeof(int));
    char * buf2; //sert a lire dans le fichier ?
    buf2 = malloc(sizeof(int));
    int cpt = 0;
    //Construire le message
    // for (int i = 0; i < taille_buf; i++) {
    //     sprintf(&buf[i], "%d\n", i);
    // }
    // printf("msg : %s\n", buf);
    gettimeofday(&td, NULL);
    //boucle pour ecrire puis lire 
    for (int i = 0; i < taille_buf; i++) {
        sprintf(buf, "%d", i);
        //retour a tester ? 
        write(fd1, buf, taille_buf);
        printf("write %d ok\n", i);
        read(fd2, buf2, taille_buf);
        printf("read %d ok\n", i);
        printf("Msg recu : %s\n", buf);
        cpt++;
    }
    printf("here\n");
    gettimeofday(&tf, NULL);
    float d = ((1000 * 2 * 4 * 8) * pow(10, -6))/(tf.tv_usec - td.tv_usec);
    printf("Debit : %f\n", d);
    printf("cpt : %d\n", cpt);

    //on ferme les fichiers
    close(fd1);
    printf("fermeture fichier 1\n");
    close(fd2);
    printf("fermeture fichier 2\n");
    
    //on supprime les fichiers
    unlink("tube1");
    unlink("tube2");

    return (0);
}

// int ret; ...
//     ret = read(buffer, n);
//     if (ret == -1) // <- je suis allé lire la page man de read() section RETURN VALUE
//     {
//         perror("read() du pong");
//         exit(EXIT_FAILURE);
//     }